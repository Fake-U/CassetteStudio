# Cassette Studio — Xperia 1 V build

目标设备：Sony Xperia 1 V（XQ-DQ72），Android 13+。本工程设置 `minSdk 33 / compileSdk 35 / targetSdk 35`。

## 本版接线
- WebView：黑金磁带 UI、歌词滚动、播放列表与控制面板。
- Media3 ExoPlayer：Android 原生音频播放。
- SAF：系统文件选择器导入本地音频，不申请宽泛存储权限。
- MediaMetadataRetriever：读取标题、艺术家、专辑和内嵌封面。
- Android DynamicsProcessing：7 段 Pre-EQ、3 段 MBC、Limiter；前级增益和低频增益实时控制。
- HTML 独立版仍在项目根目录 `cassette-player.html`，用 Web Audio API。

## AndroidIDE / Termux 编译
你之前的 AndroidIDE-Rv2ide 环境使用 JDK 17。把 ZIP 解压到手机可访问目录，在 AndroidIDE Terminal 进入项目根目录后运行：

```bash
bash termux-build.sh
```

如果 SDK 组件缺失，脚本会尝试调用 `sdkmanager` 安装 `platforms;android-35` 和 `build-tools;35.0.0`。APK 预期输出：
`app/build/outputs/apk/debug/app-debug.apk`

如果终端没有 `gradle` 命令，先在 AndroidIDE 项目界面打开项目并执行 Gradle Sync，再回终端运行脚本。

## 注意
- 当前工作环境没有 Android SDK/Gradle，因此这里不能生成或验证 APK；该 ZIP 是针对 Xperia 1 V 的 Android Studio/AndroidIDE 项目，不应误认为已通过真机测试。
- DynamicsProcessing 是否能接管当前输出路径，取决于系统音频策略、厂商实现、蓝牙/USB 输出路径及其他音效服务。请在 Xperia 1 V 上试听验证。
- HTML 中浏览器模式保留 Web Audio；Android 模式自动使用原生桥接。LRC 仍通过“导入 LRC”按钮加载，建议歌词文件与歌曲同名。

## 云端一键编译（GitHub Actions）

项目已附带 `.github/workflows/android-apk.yml`。GitHub Actions 会在云端 Ubuntu 环境安装 JDK 17、Android SDK 35、Gradle 8.9 并编译 APK，不需要在手机上安装 Android SDK。

操作步骤：
1. 在 GitHub 新建一个空仓库（建议 Private）。
2. 将本 ZIP 解压，把里面的全部文件和隐藏目录 `.github` 一并上传到仓库根目录并提交到 `main`。
3. 打开仓库的 **Actions** 页面，选择 **Build Cassette Studio APK**，点击 **Run workflow**。
4. 等待任务结束；进入该次运行页面底部的 **Artifacts**，下载 `CassetteStudio-Xperia1V-debug-apk`，解压得到 `app-debug.apk`。
5. 将 APK 传到 Xperia 1 V 安装。

注意：GitHub 云端构建是本工程的自动编译通道。它不会自动把你的项目上传到 GitHub；仓库需要由你自己的 GitHub 账号创建和授权。若云端编译出现 Kotlin/Gradle 错误，把 Actions 的失败日志发回来，我可以据此修复。
