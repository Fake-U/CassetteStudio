#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")" && pwd)"
cd "$ROOT"
export JAVA_HOME="${JAVA_HOME:-$(dirname "$(dirname "$(readlink -f "$(command -v java)")")")}"
export ANDROID_HOME="${ANDROID_HOME:-$HOME/android-sdk}"
export ANDROID_SDK_ROOT="$ANDROID_HOME"
mkdir -p "$ANDROID_HOME"
echo "JAVA_HOME=$JAVA_HOME"
echo "ANDROID_HOME=$ANDROID_HOME"

if ! command -v gradle >/dev/null 2>&1; then
  echo "ERROR: gradle command not found. Open this project in AndroidIDE and run Gradle Sync first."
  exit 2
fi

if [ -x "$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager" ]; then
  SDKMANAGER="$ANDROID_HOME/cmdline-tools/latest/bin/sdkmanager"
elif command -v sdkmanager >/dev/null 2>&1; then
  SDKMANAGER="$(command -v sdkmanager)"
else
  SDKMANAGER=""
fi

if [ ! -d "$ANDROID_HOME/platforms/android-35" ] || [ ! -d "$ANDROID_HOME/build-tools/35.0.0" ]; then
  if [ -n "$SDKMANAGER" ]; then
    yes | "$SDKMANAGER" --sdk_root="$ANDROID_HOME" "platforms;android-35" "build-tools;35.0.0" "platform-tools"
  else
    echo "ERROR: Android SDK Platform 35 / Build Tools 35.0.0 missing and sdkmanager not found."
    echo "Install them in AndroidIDE SDK Manager, then run this script again."
    exit 3
  fi
fi

gradle --no-daemon :app:assembleDebug
echo
echo "APK: $ROOT/app/build/outputs/apk/debug/app-debug.apk"
