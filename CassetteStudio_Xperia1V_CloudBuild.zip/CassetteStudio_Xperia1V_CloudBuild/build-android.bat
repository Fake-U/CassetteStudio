@echo off
setlocal
if not exist app\src\main\assets mkdir app\src\main\assets
where gradle >nul 2>nul
if errorlevel 1 (
  echo Gradle command not found. Open in Android Studio and Sync Project first.
  pause
  exit /b 1
)
gradle :app:assembleDebug
pause
