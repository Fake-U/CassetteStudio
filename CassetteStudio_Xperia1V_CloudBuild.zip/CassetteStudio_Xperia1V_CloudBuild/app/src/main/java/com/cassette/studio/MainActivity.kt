package com.cassette.studio

import android.media.MediaMetadataRetriever
import android.media.audiofx.DynamicsProcessing
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : ComponentActivity() {
    private lateinit var web: WebView
    private lateinit var player: ExoPlayer
    private var dynamics: DynamicsProcessing? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private val progressTask = object : Runnable {
        override fun run() {
            if (::player.isInitialized && ::web.isInitialized) {
                val duration = if (player.duration > 0) player.duration else 0L
                web.evaluateJavascript(
                    "window.onNativeProgress&&window.onNativeProgress(${player.currentPosition},$duration,${player.isPlaying})", null
                )
            }
            mainHandler.postDelayed(this, 400)
        }
    }

    private val picker = registerForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNullOrEmpty()) return@registerForActivityResult
        val result = JSONArray()
        uris.forEach { uri ->
            try {
                contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
            } catch (_: Exception) {}
            result.put(readMetadata(uri))
        }
        web.evaluateJavascript("window.onNativeFiles&&window.onNativeFiles($result)", null)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        player = ExoPlayer.Builder(this).build()
        player.addListener(object : Player.Listener {
            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                attachDynamics(audioSessionId)
            }
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_ENDED) {
                    web.evaluateJavascript("window.onNativeEnded&&window.onNativeEnded()", null)
                }
            }
        })
        web = WebView(this).apply {
            settings.javaScriptEnabled = true
            settings.domStorageEnabled = true
            settings.allowFileAccess = true
            settings.allowContentAccess = true
            settings.javaScriptCanOpenWindowsAutomatically = false
            webChromeClient = WebChromeClient()
            webViewClient = WebViewClient()
            addJavascriptInterface(AudioBridge(), "AndroidAudio")
            loadUrl("file:///android_asset/cassette-player.html")
        }
        setContentView(web)
        mainHandler.post(progressTask)
    }

    private fun readMetadata(uri: Uri): JSONObject {
        val out = JSONObject()
        out.put("uri", uri.toString())
        out.put("fileName", uri.lastPathSegment ?: "")
        val retriever = MediaMetadataRetriever()
        try {
            retriever.setDataSource(this, uri)
            out.put("title", retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE) ?: "未知曲目")
            out.put("artist", retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST) ?: "未知艺术家")
            out.put("album", retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM) ?: "本地音乐")
            val picture = retriever.embeddedPicture
            if (picture != null && picture.size <= 2_500_000) {
                out.put("cover", "data:image/jpeg;base64," + Base64.encodeToString(picture, Base64.NO_WRAP))
            }
        } catch (_: Exception) {
            out.put("title", uri.lastPathSegment ?: "未知曲目")
            out.put("artist", "未知艺术家")
            out.put("album", "本地音乐")
        } finally {
            try { retriever.release() } catch (_: Exception) {}
        }
        return out
    }

    inner class AudioBridge {
        @JavascriptInterface fun chooseAudio() {
            runOnUiThread { picker.launch(arrayOf("audio/*")) }
        }
        @JavascriptInterface fun playUri(uri: String) {
            runOnUiThread {
                player.setMediaItem(MediaItem.fromUri(Uri.parse(uri)))
                player.prepare()
                player.play()
            }
        }
        @JavascriptInterface fun play() { runOnUiThread { player.play() } }
        @JavascriptInterface fun pause() { runOnUiThread { player.pause() } }
        @JavascriptInterface fun seek(positionMs: Double) {
            runOnUiThread { player.seekTo(positionMs.toLong().coerceAtLeast(0L)) }
        }
        @JavascriptInterface fun setVolume(value: Double) {
            runOnUiThread { player.volume = value.toFloat().coerceIn(0f, 1f) }
        }
        @JavascriptInterface fun setEnabled(enabled: Boolean) {
            runOnUiThread {
                if (!enabled) { dynamics?.release(); dynamics = null }
                else if (player.audioSessionId != 0) attachDynamics(player.audioSessionId)
            }
        }
        @JavascriptInterface fun setPreamp(db: Double) {
            runOnUiThread {
                try {
                    dynamics?.setInputGainAllChannelsTo(db.toFloat().coerceIn(-12f, 12f))
                } catch (e: Exception) { e.printStackTrace() }
            }
        }
        @JavascriptInterface fun setEqBand(index: Int, gainDb: Double) {
            runOnUiThread {
                val effect = dynamics ?: return@runOnUiThread
                try {
                    val band = effect.getPreEqBandByChannelIndex(0, index)
                    band.gain = gainDb.toFloat().coerceIn(-12f, 12f)
                    effect.setPreEqBandAllChannelsTo(index, band)
                } catch (e: Exception) { e.printStackTrace() }
            }
        }
        @JavascriptInterface fun setBass(amount: Int) {
            runOnUiThread { setEqGain(0, amount.coerceIn(0, 100) * 0.10f) }
        }
        @JavascriptInterface fun setCompressor(amount: Int) {
            runOnUiThread {
                val effect = dynamics ?: return@runOnUiThread
                try {
                    val cfg = effect.config
                    val count = cfg.getMbcByChannelIndex(0).bandCount
                    val strength = amount.coerceIn(0, 100) / 100f
                    for (i in 0 until count) {
                        val band = effect.getMbcBandByChannelIndex(0, i)
                        band.ratio = 1f + strength * 5f
                        band.threshold = -12f - strength * 24f
                        band.attackTime = 10f
                        band.releaseTime = 180f
                        effect.setMbcBandAllChannelsTo(i, band)
                    }
                } catch (e: Exception) { e.printStackTrace() }
            }
        }
    }

    private fun setEqGain(index: Int, gain: Float) {
        val effect = dynamics ?: return
        try {
            val band = effect.getPreEqBandByChannelIndex(0, index)
            band.gain = gain
            effect.setPreEqBandAllChannelsTo(index, band)
        } catch (e: Exception) { e.printStackTrace() }
    }

    private fun attachDynamics(sessionId: Int) {
        if (sessionId == 0) return
        try {
            dynamics?.release()
            val config = DynamicsProcessing.Config.Builder(
                DynamicsProcessing.VARIANT_FAVOR_FREQUENCY_RESOLUTION,
                2,
                true, 7,
                true, 3,
                false, 0,
                true
            ).setPreferredFrameDuration(10f).setInputGainAllChannelsTo(0f).build()
            dynamics = DynamicsProcessing(0, sessionId, config).apply { enabled = true }
        } catch (e: Exception) {
            dynamics = null
            e.printStackTrace()
        }
    }

    override fun onDestroy() {
        mainHandler.removeCallbacks(progressTask)
        dynamics?.release()
        player.release()
        web.destroy()
        super.onDestroy()
    }
}
